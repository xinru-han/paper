"""
Agent-Based Model of corn-soybean planting decisions, Heilongjiang.
Vectorised NumPy implementation. Behavioural parameters are read from
behavior_params.json (estimated in the econometric layer). Only the year loop
is explicit; agents and Monte-Carlo replicates are vectorised.

Modules (per research plan Phase 4):
  abm_init          -> build agent state arrays from initial cross-section
  abm_expectations  -> form price / yield expectations for year t
  abm_decide        -> participation draw + soybean share
  abm_realize       -> realise prices, yields, incomes, fiscal cost
  abm_step          -> one full annual time step
  run_scenario      -> run a policy scenario over the horizon, MC replicates
"""
import numpy as np
import json


def load_params(path):
    with open(path) as f:
        return json.load(f)


def _linpred_participation(P, state, dpi100, peer, plant_soy_lag):
    c = P["coefficients"]
    xb = (state["intercept_part"]
          + c.get("dpi100", 0.0) * dpi100
          + c.get("plant_soy_lag", 0.0) * plant_soy_lag
          + c.get("peer_lag", 0.0) * peer
          + c.get("logB", 0.0) * state["logB"]
          + c.get("head_age10", 0.0) * state["head_age10"]
          + c.get("head_edu", 0.0) * state["head_edu"]
          + c.get("insurance", 0.0) * state["insurance"]
          + c.get("offfarm_n", 0.0) * state["offfarm_n"])
    return xb


def _linpred_share(P, state, dpi100):
    """Conditional soybean share among planters (intensive margin)."""
    c = P["coefficients"]
    xb = (c.get("Intercept", 0.0)
          + c.get("dpi100", 0.0) * dpi100
          + c.get("logB", 0.0) * state["logB"]
          + c.get("head_age10", 0.0) * state["head_age10"])
    return xb


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -30, 30)))


def abm_init(agent_df, params, n_mc=500, seed=20260705):
    """Build the agent state dict. Static traits shape (N,); stochastic state (N, n_mc).
    County fixed effects from the estimated model fold into an agent intercept."""
    rng = np.random.default_rng(seed)
    N = len(agent_df)
    P = params["participation_logit"]["coefficients"]
    S = params["share_fraclogit"]["coefficients"]
    county = agent_df["county"].to_numpy()

    def county_fe(coefs):
        fe = np.zeros(N)
        for i, c in enumerate(county):
            fe[i] = coefs.get(f"C(county)[T.{c}]", 0.0)
        return fe
    part_int = P.get("Intercept", 0.0) + county_fe(P)
    share_int = S.get("Intercept", 0.0) + county_fe(S)

    state = {
        "N": N, "n_mc": n_mc, "county": county,
        "county_name": agent_df["county_name"].to_numpy(),
        "village": agent_df["village"].to_numpy(),
        "B": agent_df["B"].to_numpy(float),
        "logB": agent_df["logB"].to_numpy(float),
        "head_age10": agent_df["head_age10"].to_numpy(float),
        "head_edu": agent_df["head_edu"].to_numpy(float),
        "insurance": agent_df["insurance"].to_numpy(float),
        "offfarm_n": agent_df["offfarm_n"].to_numpy(float),
        "ey_corn": agent_df["ey_corn"].to_numpy(float),
        "ey_soy": agent_df["ey_soy"].to_numpy(float),
        "intercept_part": part_int, "intercept_share": share_int,
    }
    ones = np.ones((1, n_mc))
    state["s_prev"] = agent_df["s_init"].to_numpy(float)[:, None] * ones
    state["plant_soy_prev"] = agent_df["plant_soy_init"].to_numpy(float)[:, None] * ones
    state["p_corn_mem"] = agent_df["p_corn"].to_numpy(float)[:, None] * ones
    state["p_soy_mem"] = agent_df["p_soy"].to_numpy(float)[:, None] * ones
    sigma_a = params.get("sigma_a", 0.5)
    state["a_i"] = rng.normal(0, sigma_a, size=(N, n_mc))
    state["rng"] = rng
    return state


def abm_expectations(state, scenario, t, params, lam_e=1.0):
    econ = params["econ"]
    d_rot, d_rep = econ["delta_rot"], econ["delta_rep"]
    p_corn = scenario["p_corn"][t] * np.ones_like(state["p_corn_mem"])
    p_soy = scenario["p_soy"][t] * np.ones_like(state["p_soy_mem"])
    p_corn_hat = lam_e * p_corn + (1 - lam_e) * state["p_corn_mem"]
    p_soy_hat = lam_e * p_soy + (1 - lam_e) * state["p_soy_mem"]
    s_prev = state["s_prev"]
    ey_corn = state["ey_corn"][:, None] * (1 + d_rot * s_prev)
    ey_soy = state["ey_soy"][:, None] * (1 - d_rep * s_prev)
    return dict(p_corn_hat=p_corn_hat, p_soy_hat=p_soy_hat, ey_corn=ey_corn, ey_soy=ey_soy)


def _dpi(exp, scenario, t, params):
    econ = params["econ"]; cost = econ["cost_per_mu"]
    pi_corn = exp["p_corn_hat"] * exp["ey_corn"] - cost["corn"] + scenario["sub_corn"][t]
    pi_soy = exp["p_soy_hat"] * exp["ey_soy"] - cost["soy"] + scenario["sub_soy"][t]
    return pi_soy - pi_corn


def _state2d(state, keys):
    return {k: (state[k][:, None] if state[k].ndim == 1 else state[k]) for k in keys}


def abm_decide(state, exp, scenario, t, params, peer):
    P = params["participation_logit"]
    S = params.get("share_fraclogit_conditional", params["share_fraclogit"])
    dpi = _dpi(exp, scenario, t, params)
    dpi100 = dpi / 100.0
    sp = _state2d(state, ["intercept_part", "logB", "head_age10", "head_edu", "insurance", "offfarm_n"])
    xb = _linpred_participation(P, sp, dpi100, peer, state["plant_soy_prev"]) + state["a_i"]
    prob = _sigmoid(xb)
    u = state["rng"].random(prob.shape)
    plant_soy = (u < prob).astype(float)
    ss = _state2d(state, ["logB", "head_age10"])
    s_mean = _sigmoid(_linpred_share(S, ss, dpi100))
    s = np.where(plant_soy > 0, np.clip(s_mean, 1e-3, 1.0), 0.0)
    return plant_soy, s, prob, dpi


def abm_realize(state, exp, scenario, t, plant_soy, s, params):
    econ = params["econ"]; cost = econ["cost_per_mu"]; rng = state["rng"]
    N, M = state["N"], state["n_mc"]
    sig_p = params.get("sigma_p", 0.08); sig_y = params.get("sigma_y", 0.15)
    p_corn = exp["p_corn_hat"] * np.exp(rng.normal(0, sig_p, size=(N, M)))
    p_soy = exp["p_soy_hat"] * np.exp(rng.normal(0, sig_p, size=(N, M)))
    y_corn = exp["ey_corn"] * np.exp(rng.normal(0, sig_y, size=(N, M)))
    y_soy = exp["ey_soy"] * np.exp(rng.normal(0, sig_y, size=(N, M)))
    B = state["B"][:, None]
    area_soy = s * B; area_corn = (1 - s) * B
    rot_area = np.minimum(s, np.maximum(0, 1 - state["s_prev"])) * B
    sc, ss, sr = scenario["sub_corn"][t], scenario["sub_soy"][t], scenario["sub_rot"][t]
    income = (area_corn * (p_corn * y_corn - cost["corn"] + sc)
              + area_soy * (p_soy * y_soy - cost["soy"] + ss)
              + rot_area * sr)
    fiscal = area_corn * sc + area_soy * ss + rot_area * sr
    return dict(income=income, fiscal=fiscal, area_soy=area_soy, area_corn=area_corn,
                p_corn=p_corn, p_soy=p_soy)


def _village_peer(state):
    villages = state["village"]; s_prev = state["s_prev"]
    peer = np.zeros_like(s_prev)
    for v in np.unique(villages):
        idx = np.where(villages == v)[0]
        if len(idx) <= 1:
            continue
        block = s_prev[idx]
        tot = block.sum(axis=0, keepdims=True)
        peer[idx] = (tot - block) / (len(idx) - 1)
    return peer


def abm_step(state, scenario, t, params, lam_e=1.0, peer_on=True):
    exp = abm_expectations(state, scenario, t, params, lam_e=lam_e)
    peer = _village_peer(state) if peer_on else np.zeros((state["N"], state["n_mc"]))
    plant_soy, s, prob, dpi = abm_decide(state, exp, scenario, t, params, peer)
    out = abm_realize(state, exp, scenario, t, plant_soy, s, params)
    state["s_prev"] = s
    state["plant_soy_prev"] = plant_soy
    state["p_corn_mem"] = out["p_corn"]
    state["p_soy_mem"] = out["p_soy"]
    out.update(plant_soy=plant_soy, s=s, prob=prob, dpi=dpi)
    return out


def make_scenario(years, p_corn, p_soy, sub_corn, sub_soy, sub_rot):
    n = len(years)
    def arr(x):
        return np.asarray(x, float) if np.ndim(x) else np.full(n, float(x))
    return dict(years=list(years), p_corn=arr(p_corn), p_soy=arr(p_soy),
                sub_corn=arr(sub_corn), sub_soy=arr(sub_soy), sub_rot=arr(sub_rot))


def run_scenario(agent_df, params, scenario, n_mc=500, seed=20260705, lam_e=1.0, peer_on=True):
    state = abm_init(agent_df, params, n_mc=n_mc, seed=seed)
    years = scenario["years"]
    rec = {k: [] for k in ["year", "soy_particip", "soy_particip_sd", "soy_share",
                           "soy_share_sd", "fiscal", "fiscal_sd", "soy_area", "total_area"]}
    per_county = {c: {"year": [], "soy_share": []} for c in np.unique(state["county_name"])}
    for t, yr in enumerate(years):
        out = abm_step(state, scenario, t, params, lam_e=lam_e, peer_on=peer_on)
        B = state["B"][:, None]
        share_rep = out["area_soy"].sum(0) / B.sum()
        part_rep = out["plant_soy"].mean(0)
        fiscal_rep = out["fiscal"].sum(0)
        rec["year"].append(yr)
        rec["soy_particip"].append(float(part_rep.mean()))
        rec["soy_particip_sd"].append(float(part_rep.std()))
        rec["soy_share"].append(float(share_rep.mean()))
        rec["soy_share_sd"].append(float(share_rep.std()))
        rec["fiscal"].append(float(fiscal_rep.mean()))
        rec["fiscal_sd"].append(float(fiscal_rep.std()))
        rec["soy_area"].append(float(out["area_soy"].sum(0).mean()))
        rec["total_area"].append(float(B.sum()))
        for c in per_county:
            m = state["county_name"] == c
            sh = out["area_soy"][m].sum(0) / B[m].sum()
            per_county[c]["year"].append(yr)
            per_county[c]["soy_share"].append(float(sh.mean()))
    return dict(agg=rec, per_county=per_county, final_state=state)
