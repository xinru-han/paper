# 追加处理与稳健性估计结果

## 一、已补充内容

- 主结果采用全国非食品 CPI；稳健性用食物支出份额近似反推出省级非食品 CPI。
- 构造 `cpi_nonfood` 省级近似非食品价格口径并重新估计 AIDADS/MAIDADS。
- 对每个 `variant × model` 分别用 2015-2020 年训练、2021-2023 年测试，以及 2015-2022 年训练、2023 年测试做样本外验证。
- 做 30 次省份簇 bootstrap，其中 23 次完全收敛；关键区间仅用完全收敛 draw 汇总。

## 二、CPI 非食品稳健性估计
- AIDADS_sat: nll=-4374.256, success=True, message=CONVERGENCE: RELATIVE REDUCTION OF F <= FACTR*EPSMCH
- MAIDADS_sat: nll=-4477.105, success=True, message=CONVERGENCE: RELATIVE REDUCTION OF F <= FACTR*EPSMCH

## 三、样本外验证
| variant | model | train_years | test_years | group | rmse_x | mae_x | mean_x | n_test | relative_rmse |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | dairyegg | 0.0126177 | 0.0102732 | 0.0336588 | 93 | 0.374872 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | grain | 0.0695262 | 0.0568454 | 0.420289 | 93 | 0.165425 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | meatother | 0.0195748 | 0.015341 | 0.0454472 | 93 | 0.430715 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | nonfood | 4.08956 | 3.35693 | 198.051 | 93 | 0.020649 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | oil | 0.0321031 | 0.0247447 | 0.128885 | 93 | 0.249084 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | pork | 0.0540721 | 0.0440353 | 0.125098 | 93 | 0.432237 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | vegfruit | 0.0119403 | 0.00983787 | 0.0550384 | 93 | 0.216944 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | dairyegg | 0.0128855 | 0.0104668 | 0.0336588 | 93 | 0.382827 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | grain | 0.0720158 | 0.0583484 | 0.420289 | 93 | 0.171348 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | meatother | 0.0183709 | 0.0141836 | 0.0454472 | 93 | 0.404226 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | nonfood | 4.01791 | 3.32331 | 198.051 | 93 | 0.0202872 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | oil | 0.0323636 | 0.0254476 | 0.128885 | 93 | 0.251105 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | pork | 0.0526016 | 0.041852 | 0.125098 | 93 | 0.420483 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | vegfruit | 0.0116282 | 0.00959265 | 0.0550384 | 93 | 0.211274 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2022 | 2023 | dairyegg | 0.0128383 | 0.0103528 | 0.0348762 | 31 | 0.36811 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2022 | 2023 | grain | 0.0681933 | 0.0552256 | 0.404668 | 31 | 0.168517 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2022 | 2023 | meatother | 0.0200842 | 0.0156359 | 0.0474614 | 31 | 0.423169 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2022 | 2023 | nonfood | 3.83724 | 3.30784 | 205.931 | 31 | 0.0186336 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2022 | 2023 | oil | 0.032018 | 0.0266835 | 0.126385 | 31 | 0.253336 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2022 | 2023 | pork | 0.0586961 | 0.0450047 | 0.136188 | 31 | 0.430992 |
| baseline_real_national_nonfood | AIDADS_sat | 2015-2022 | 2023 | vegfruit | 0.0122971 | 0.0100908 | 0.0563143 | 31 | 0.218366 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2022 | 2023 | dairyegg | 0.0124379 | 0.0101192 | 0.0348762 | 31 | 0.356629 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2022 | 2023 | grain | 0.0692087 | 0.0576068 | 0.404668 | 31 | 0.171026 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2022 | 2023 | meatother | 0.019445 | 0.0150328 | 0.0474614 | 31 | 0.409702 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2022 | 2023 | nonfood | 4.08565 | 3.49799 | 205.931 | 31 | 0.0198399 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2022 | 2023 | oil | 0.0315686 | 0.02568 | 0.126385 | 31 | 0.249781 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2022 | 2023 | pork | 0.057055 | 0.0453392 | 0.136188 | 31 | 0.418941 |
| baseline_real_national_nonfood | MAIDADS_sat | 2015-2022 | 2023 | vegfruit | 0.0117596 | 0.00945762 | 0.0563143 | 31 | 0.20882 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | dairyegg | 0.0129299 | 0.0104617 | 0.0336588 | 93 | 0.384147 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | grain | 0.0688373 | 0.0564493 | 0.420289 | 93 | 0.163786 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | meatother | 0.0192086 | 0.0149997 | 0.0454472 | 93 | 0.422657 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | nonfood | 4.10071 | 3.36496 | 198.042 | 93 | 0.0207063 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | oil | 0.0321476 | 0.0247361 | 0.128885 | 93 | 0.249429 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | pork | 0.0538773 | 0.0439161 | 0.125098 | 93 | 0.43068 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2020 | 2021-2023 | vegfruit | 0.0122691 | 0.0101921 | 0.0550384 | 93 | 0.22292 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | dairyegg | 0.0129495 | 0.0105103 | 0.0336588 | 93 | 0.38473 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | grain | 0.0729421 | 0.0589606 | 0.420289 | 93 | 0.173552 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | meatother | 0.0184625 | 0.0142437 | 0.0454472 | 93 | 0.406242 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | nonfood | 4.05871 | 3.36023 | 198.042 | 93 | 0.0204941 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | oil | 0.0324181 | 0.0253134 | 0.128885 | 93 | 0.251528 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | pork | 0.0524954 | 0.0417915 | 0.125098 | 93 | 0.419634 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2020 | 2021-2023 | vegfruit | 0.0116443 | 0.00960731 | 0.0550384 | 93 | 0.211567 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2022 | 2023 | dairyegg | 0.0127378 | 0.0102828 | 0.0348762 | 31 | 0.365228 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2022 | 2023 | grain | 0.066744 | 0.054371 | 0.404668 | 31 | 0.164935 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2022 | 2023 | meatother | 0.0198078 | 0.0153814 | 0.0474614 | 31 | 0.417344 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2022 | 2023 | nonfood | 3.79574 | 3.27162 | 205.931 | 31 | 0.0184321 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2022 | 2023 | oil | 0.0319578 | 0.0263279 | 0.126385 | 31 | 0.25286 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2022 | 2023 | pork | 0.0586798 | 0.0442686 | 0.136188 | 31 | 0.430872 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | 2015-2022 | 2023 | vegfruit | 0.0119893 | 0.00969884 | 0.0563143 | 31 | 0.212901 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2022 | 2023 | dairyegg | 0.0125662 | 0.0101835 | 0.0348762 | 31 | 0.360309 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2022 | 2023 | grain | 0.0706137 | 0.0586122 | 0.404668 | 31 | 0.174498 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2022 | 2023 | meatother | 0.019278 | 0.0148853 | 0.0474614 | 31 | 0.406182 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2022 | 2023 | nonfood | 4.14064 | 3.53425 | 205.931 | 31 | 0.0201069 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2022 | 2023 | oil | 0.0314002 | 0.0253596 | 0.126385 | 31 | 0.248448 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2022 | 2023 | pork | 0.0569136 | 0.0453182 | 0.136188 | 31 | 0.417903 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | 2015-2022 | 2023 | vegfruit | 0.0118954 | 0.00963414 | 0.0563143 | 31 | 0.211233 |

## 四、模型比较
| variant | model | nll | k_effective | aic | bic | success | lr_stat | p_value_chi2 | chi2_p_value_status | cluster_bootstrap_tail_probability | lr_bootstrap_successful_reps | oos_food_rmse_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| baseline_real_national_nonfood | AIDADS_sat | -4248.29 | 14 | -8468.57 | -8416.26 | True |  |  |  |  |  | 0.0336634 |
| baseline_real_national_nonfood | MAIDADS_sat | -4344.23 | 22 | -8644.46 | -8562.25 | True |  |  |  |  |  | 0.033445 |
| robust_real_derived_cpi_nonfood | AIDADS_sat | -4374.26 | 14 | -8720.51 | -8668.2 | True |  |  |  |  |  | 0.0334322 |
| robust_real_derived_cpi_nonfood | MAIDADS_sat | -4477.1 | 22 | -8910.21 | -8828.01 | True |  |  |  |  |  | 0.0336316 |
| baseline_real_national_nonfood | LR_MAIDADS_vs_AIDADS |  | 8 |  |  | True | 191.888 |  | invalid_not_reported_unidentified_nuisance_under_H0 | 0.5 | 10 |  |

## 五、LR bootstrap（pilot）

普通 χ² p 值因 MAIDADS 在 AIDADS 原假设下存在不可识别 nuisance parameter，本轮不作为有效推断报告。
| test | observed_lr | bootstrap_reps | successful_reps | cluster_bootstrap_tail_probability | lr_bootstrap_median | lr_bootstrap_q95 | chi2_p_value_status | note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MAIDADS_vs_AIDADS | 191.888 | 12 | 10 | 0.5 | 189.944 | 455.931 | invalid_not_reported | Cluster bootstrap pilot; chi-square reference not used. |

## 六、bootstrap 关键区间
| metric | group_or_item | year | ci_2_5 | median | ci_97_5 |
| --- | --- | --- | --- | --- | --- |
| daily_kcal_per_cap_weighted | dairyegg | 2050 | 56.2952 | 63.0315 | 70.6684 |
| daily_kcal_per_cap_weighted | grain | 2050 | 453.063 | 486.36 | 625.824 |
| daily_kcal_per_cap_weighted | meatother | 2050 | 77.846 | 91.4488 | 103.008 |
| daily_kcal_per_cap_weighted | oil | 2050 | 230.086 | 261.267 | 285.381 |
| daily_kcal_per_cap_weighted | pork | 2050 | 223.778 | 244.323 | 272.603 |
| daily_kcal_per_cap_weighted | vegfruit | 2050 | 103.896 | 109.68 | 118.714 |
| feed_grain_million_ton | aquatic | 2050 | 21.6829 | 25.4853 | 28.707 |
| feed_grain_million_ton | beef | 2050 | 35.2915 | 41.4549 | 46.6946 |
| feed_grain_million_ton | egg | 2050 | 38.0709 | 42.6258 | 47.7695 |
| feed_grain_million_ton | milk | 2050 | 8.85453 | 9.91458 | 11.1288 |
| feed_grain_million_ton | mutton | 2050 | 21.4629 | 25.1944 | 28.3786 |
| feed_grain_million_ton | pork | 2050 | 120.205 | 131.241 | 146.432 |
| feed_grain_million_ton | poultry | 2050 | 43.6533 | 51.2736 | 57.7548 |

## 七、输出文件

- `province_cpi_indices.csv`：省级总/食品/近似非食品 CPI 与 2023=100 指数。
- `robustness_cpi_nonfood_parameter_estimates.csv`：CPI 非食品价格口径参数。
- `robustness_cpi_nonfood_fit_by_group.csv`：CPI 非食品价格口径拟合误差。
- `robustness_cpi_nonfood_projection_group_2030_2035_2050.csv`：CPI 稳健预测。
- `oos_fit_by_group.csv`、`oos_predictions.csv` 与 `Results/OOS/oos_predictions__*.csv`：按口径、模型、样本切分独立保存的样本外验证。
- `bootstrap_key_ci.csv`、`bootstrap_parameter_ci.csv`、`bootstrap_draw_metrics.csv`：bootstrap 区间和抽样明细。
- `lr_test_chi2_and_bootstrap.csv`、`lr_bootstrap_draws.csv`：LR 检验的 cluster bootstrap 摘要和抽样明细。

## 八、仍需人工确认

- 食品 CPI 三个文件是分段表，本脚本按年份拼接；请后续核对 2015 年以前文件是否确为同一食品分类口径。
- 省级非食品 CPI 由总 CPI、食品 CPI、食物支出份额反推，是近似值；更理想的是直接拿到省级非食品 CPI。
- 当前 bootstrap 或 LR bootstrap 仍低于正式规模；正式论文版请把对应 reps 提高到 500-1000。